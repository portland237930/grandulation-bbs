
insert into t_attribute (name,_type,cid,val) value ('品牌','static',65,'soulkiss');
insert into t_attribute (name,_type,cid,val) value ('适用年龄','static',65,'25-29周岁');
insert into t_attribute (name,_type,cid,val) value ('材质','static',65,'蚕丝');
insert into t_attribute (name,_type,cid,val) value ('尺码','static',65,'S M L');
insert into t_attribute (name,_type,cid,val) value ('面料','static',65,'其他');
insert into t_attribute (name,_type,cid,val) value ('图案','static',65,'纯色');
insert into t_attribute (name,_type,cid,val) value ('风格','static',65,'通勤');
insert into t_attribute (name,_type,cid,val) value ('通勤','static',65,'简约');
insert into t_attribute (name,_type,cid,val) value ('领型','static',65,'立领');
insert into t_attribute (name,_type,cid,val) value ('衣门襟','static',65,'单排扣');
insert into t_attribute (name,_type,cid,val) value ('颜色分类','static',65,'冷艳红梨色-100%桑蚕丝 高雅浅杏-100%桑蚕丝 高雅浅杏-100%桑蚕丝-36517批次 冷艳红梨色-100%桑蚕丝-预售 高雅浅杏-100%桑蚕丝-预售 无视洗涤说明概不负责');
insert into t_attribute (name,_type,cid,val) value ('组合形式','static',65,'单件');
insert into t_attribute (name,_type,cid,val) value ('货号','static',65,'S904548');
insert into t_attribute (name,_type,cid,val) value ('成分含量','static',65,'95%以上');
insert into t_attribute (name,_type,cid,val) value ('裙型','static',65,'A字裙');
insert into t_attribute (name,_type,cid,val) value ('年份季节','static',65,'2019年夏季');
insert into t_attribute (name,_type,cid,val) value ('袖长','static',65,'无袖');
insert into t_attribute (name,_type,cid,val) value ('裙长','static',65,'中长裙');
insert into t_attribute (name,_type,cid,val) value ('款式','static',65,'其他/other');
insert into t_attribute (name,_type,cid,val) value ('廓形','static',65,'A型');

insert into t_attribute (name,_type,cid,val) value ('尺码','dynamic',65,'S,M,L');	
insert into t_attribute (name,_type,cid,val) value ('颜色分类','dynamic',65,'冷艳红梨色-100%桑蚕丝,高雅浅杏-100%桑蚕丝,高雅浅杏-100%桑蚕丝-36517批次,冷艳红梨色-100%桑蚕丝-预售,高雅浅杏-100%桑蚕丝-预售,无视洗涤说明概不负责');


